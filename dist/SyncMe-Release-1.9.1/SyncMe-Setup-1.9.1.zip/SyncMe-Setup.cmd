@echo off
setlocal EnableExtensions
title SyncMe Setup
echo Copyright (c) 2026 Bradford Lotriet - brad@web-zilla.co.za
set "INSTALL=C:\SyncMe"
set "HERE=%~dp0"
set "PAYLOAD=%HERE%SyncMe-Payload.zip"
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"

if not exist "%PAYLOAD%" (
  echo Missing SyncMe-Payload.zip next to this script.
  pause
  exit /b 1
)

echo SyncMe setup
echo Install folder: %INSTALL%
echo.

"%PS%" -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop';" ^
  "$install='%INSTALL%';" ^
  "$zip='%PAYLOAD%';" ^
  "if (-not (Test-Path -LiteralPath $install)) { New-Item -ItemType Directory -Path $install -Force | Out-Null };" ^
  "$cfg = Join-Path $install 'Config.ps1';" ^
  "$setsJson = Join-Path $install 'Config\sets.json';" ^
  "$preserve = $false; $tmp = $null; $preserveSets = $false; $tmpSets = $null;" ^
  "if (Test-Path -LiteralPath $cfg) { $preserve = $true; $tmp = Join-Path $env:TEMP ('SyncMe-Config-' + [guid]::NewGuid().ToString() + '.ps1'); Copy-Item -LiteralPath $cfg -Destination $tmp -Force };" ^
  "if (Test-Path -LiteralPath $setsJson) { $preserveSets = $true; $tmpSets = Join-Path $env:TEMP ('SyncMe-Sets-' + [guid]::NewGuid().ToString() + '.json'); Copy-Item -LiteralPath $setsJson -Destination $tmpSets -Force };" ^
  "Add-Type -AssemblyName System.IO.Compression.FileSystem;" ^
  "$tmpExtract = Join-Path $env:TEMP ('SyncMe-Extract-' + [guid]::NewGuid().ToString());" ^
  "New-Item -ItemType Directory -Path $tmpExtract -Force | Out-Null;" ^
  "[IO.Compression.ZipFile]::ExtractToDirectory($zip, $tmpExtract);" ^
  ". (Join-Path $tmpExtract 'Modules\InstallMerge.ps1');" ^
  "Copy-SyncMeTreeMerge -SourceRoot $tmpExtract -DestRoot $install;" ^
  "Clear-SyncMeNestedInstallJunk -InstallRoot $install;" ^
  "Remove-Item -LiteralPath $tmpExtract -Recurse -Force -ErrorAction SilentlyContinue;" ^
  "if ($preserve -and $tmp -and (Test-Path -LiteralPath $tmp)) { Copy-Item -LiteralPath $tmp -Destination $cfg -Force; Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue };" ^
  "if ($preserveSets -and $tmpSets -and (Test-Path -LiteralPath $tmpSets)) { $cfgDir = Join-Path $install 'Config'; if (-not (Test-Path -LiteralPath $cfgDir)) { New-Item -ItemType Directory -Path $cfgDir -Force | Out-Null }; Copy-Item -LiteralPath $tmpSets -Destination $setsJson -Force; Remove-Item -LiteralPath $tmpSets -Force -ErrorAction SilentlyContinue };" ^
  "foreach ($req in @('SyncMe-Host.ps1','Modules\Update.ps1','Modules\MonitorClient.ps1','Modules\InstallMerge.ps1','Modules\Security.ps1','Modules\Jobs.ps1','Modules\Router.ps1','Modules\ProcessRunner.ps1','Modules\Http.ps1','Modules\Controllers\ApiDispatch.ps1','Modules\UpdatePublicKey.xml','ui\js\app.js')) { if (-not (Test-Path -LiteralPath (Join-Path $install $req))) { throw ('Setup incomplete: missing ' + $req + ' under ' + $install) } };" ^
  "Write-Host ('Installed to ' + $install) -ForegroundColor Green"

if errorlevel 1 (
  echo Setup failed.
  pause
  exit /b 1
)

echo.
echo Starting SyncMe...
start "" "%INSTALL%\SyncMe.bat"
exit /b 0
